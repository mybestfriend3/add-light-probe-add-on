import bpy

from align_light_probe import align_light_probe

align_light_probe.register()