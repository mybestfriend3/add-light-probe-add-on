# ***** BEGIN GPL LICENSE BLOCK *****
#
# This is free software; you may redistribute it, and/or modify it,
# under the terms of the GNU General Public License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#  http://www.gnu.org/licenses/
#
# ***** END GPL LICENSE BLOCK *****


# Blender add-on to add a light probe aligned with selected vertices
# Install the zip (referenced at https://www.youtube.com/watch?v=swkkocpE5ho) as usual 
# (or simply run or register this script)
# Select one object or more in 3Dview (eventually in edit mode), type F3 and search for "aligned"
# Choose the type(s) of probe(s) to be added (eventually just a bounding box)
# Choose nb samples of rotation along different axis (if needed) and beware brut force is used (avoid too many samples)
# Select "mimic drivers" if the probe parameters are to be copied from probes named "AlignedCubeMapBase" and
#   "AlignedIrrVolBase"
# Demo and tuto at https://www.youtube.com/watch?v=swkkocpE5ho
# Press OK et voila


import bpy
import bmesh
import math
import random
import time
from mathutils import Vector, Matrix, Euler
from bpy.props import BoolProperty, FloatProperty, IntProperty, EnumProperty
from typing import List, Any

from bpy.types import Object, Context, MeshVertex

bl_info = {
    "name": "Add aligned light probes",
    "author": "MyBestFriend3333",
    "version": (0, 4),
    "blender": (2, 90, 1),
    "location": "F3 with keyword from add name (i.e. aligned, light , probe ) ",
    "description": "Adds new irradiance volume to selected objects or vertices",
    "warning": "",
    "wiki_url": "",
    "category": "Add Mesh"}


IRRADIANCE_PROBE_BASE = "AlignedIrrVolBase"
IRRADIANCE_PROBE_OTHER = "AlignedIrrVolOther"
CUBE_MAP_PROBE_BASE = "AlignedCubeMapBase"
CUBE_MAP_PROBE_OTHER = "AlignedCubeMapOther"
blender_cube_cords = [Vector((1, 1, 1)),
                      Vector((1, 1, -1)),
                      Vector((1, -1, 1)),
                      Vector((1, -1, -1)),
                      Vector((-1, 1, 1)),
                      Vector((-1, 1, -1)),
                      Vector((-1, -1, 1)),
                      Vector((-1, -1, -1)),
                      ]


class BoundingBox:

    def __init__(self):
        print("Create an empty bounding box")
        self.box = None

    def _coordinates_(self) -> List[Vector]:
        """
        returns vertices in same configuration as default cube in blender
        easy to assign v.co of a cube primitive
        """

        coordinates: List[Vector] = [Vector((self.box[0], self.box[2], self.box[4])),
                                     Vector((self.box[0], self.box[2], self.box[5])),
                                     Vector((self.box[0], self.box[3], self.box[4])),
                                     Vector((self.box[0], self.box[3], self.box[5])),
                                     Vector((self.box[1], self.box[2], self.box[4])),
                                     Vector((self.box[1], self.box[2], self.box[5])),
                                     Vector((self.box[1], self.box[3], self.box[4])),
                                     Vector((self.box[1], self.box[3], self.box[5])),
                                     ]

        return coordinates

    def bound(self, bme_vertices: List[Vector], mx: Matrix) -> List[Vector]:
        """
        Create a bounding box for a bunch of vertices according to an orientation matrix
        :param mx: orientation of the bounding box
        :type bme_vertices: takes a list of MeshVertex or a  list of vectors
        """

        vertices = [mx @ v for v in bme_vertices]

        xs = [v[0] for v in vertices]
        ys = [v[1] for v in vertices]
        zs = [v[2] for v in vertices]
        self.box = (min(xs), max(xs), min(ys), max(ys), min(zs), max(zs))
        return self._coordinates_()

    def volume(self):
        box = self.box
        vol = (box[1] - box[0]) * (box[3] - box[2]) * (box[5] - box[4])

        return vol

    pass


# get the selected vertices to be boxed
def get_selected_vertices(context: Context, selected: Object) -> List[Vector]:
    vertices: List[Vector] = []
    if context.active_object.mode == 'EDIT':
        bpy.ops.mesh.select_mode(type='VERT')
        # !!! need to go back object mode for the selected vertices to be the right ones !!!
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)

        for obj in selected:
            if obj.type == 'MESH':
                vertices.extend([obj.matrix_world @ v.co for v in obj.data.vertices if v.select])
            else:
                print("this was not expected")


    else:
        for obj in selected:
            if obj.type == 'MESH':
                vertices.extend([obj.matrix_world @ v.co for v in obj.data.vertices])
            else:
                vertices.extend([obj.matrix_world @ co for co in blender_cube_cords])

    return vertices


# add a driver
def add_driver(
        source, target, prop, data_path,
        index=-1, negative=False, func=''
):
    """ Add driver to source prop (at index), driven by target dataPath """

    if index != -1:
        d = source.driver_add(prop, index).driver
    else:
        d = source.driver_add(prop).driver

    v = d.variables.new()
    v.name = prop
    v.targets[0].id = target
    v.targets[0].data_path = data_path

    d.expression = func + "(" + v.name + ")" if func else v.name
    d.expression = d.expression if not negative else "-1 * " + d.expression


# mimic the radiance parameters with drivers
def mimic_radiance_param(source):
    s = source.data
    t = bpy.context.scene.objects[IRRADIANCE_PROBE_BASE]
    add_driver(s, t, 'influence_distance', 'data.influence_distance', -1)
    add_driver(s, t, 'falloff', 'data.falloff', -1)
    add_driver(s, t, 'intensity', 'data.intensity', -1)
    add_driver(s, t, 'grid_resolution_x', 'data.grid_resolution_x', -1)
    add_driver(s, t, 'grid_resolution_y', 'data.grid_resolution_y', -1)
    add_driver(s, t, 'grid_resolution_z', 'data.grid_resolution_z', -1)
    add_driver(s, t, 'clip_start', 'data.clip_start', -1)
    add_driver(s, t, 'clip_end', 'data.clip_end', -1)
    add_driver(s, t, 'visibility_buffer_bias', 'data.visibility_buffer_bias', -1)
    add_driver(s, t, 'visibility_bleed_bias', 'data.visibility_bleed_bias', -1)
    add_driver(s, t, 'visibility_blur', 'data.visibility_blur', -1)


# mimic the radiance parameters with drivers
def mimic_cube_map_param(source):
    s = source.data
    t = bpy.context.scene.objects[CUBE_MAP_PROBE_BASE]
    add_driver(s, t, 'influence_distance', 'data.influence_distance', -1)
    add_driver(s, t, 'falloff', 'data.falloff', -1)
    add_driver(s, t, 'intensity', 'data.intensity', -1)
    add_driver(s, t, 'clip_start', 'data.clip_start', -1)
    add_driver(s, t, 'clip_end', 'data.clip_end', -1)


# look for a bounding box for probes
def main(context: Context, samples_rot_x, samples_rot_y, samples_rot_z, drivers, add_cube, add_irradiance,
         add_cube_map):
    selected: List[Object] = bpy.context.selected_objects

    # Force the reference name
    if context.scene.objects.get(IRRADIANCE_PROBE_BASE) is None:
        irradiance_probe_name = IRRADIANCE_PROBE_BASE
    else:
        irradiance_probe_name = IRRADIANCE_PROBE_OTHER
    if context.scene.objects.get(CUBE_MAP_PROBE_BASE) is None:
        cube_map_probe_name = CUBE_MAP_PROBE_BASE
    else:
        cube_map_probe_name = CUBE_MAP_PROBE_OTHER

    obj: Object

    bounding_box = BoundingBox()

    start = time.time()

    vert_data = get_selected_vertices(context, selected)

    rmx: Matrix = Euler((0.0, 0.0, 0.0), 'XYZ').to_quaternion().to_matrix().to_4x4()

    min_cube = bounding_box.bound(vert_data, rmx)
    min_vol = bounding_box.volume()
    min_mx = rmx

    for nz in range(0, samples_rot_z + 1):
        for ny in range(0, samples_rot_y + 1):
            for nx in range(0, samples_rot_x + 1):

                angle_x = math.pi * nx / (samples_rot_x + 1)
                angle_y = math.pi * ny / (samples_rot_y + 1)
                angle_z = math.pi * nz / (samples_rot_z + 1)

                rmx = Euler((angle_x, angle_y, angle_z), 'XYZ').to_quaternion().to_matrix().to_4x4()

                cube = bounding_box.bound(vert_data, rmx)

                test_v = bounding_box.volume()
                if test_v < min_vol:
                    min_mx = rmx
                    min_vol = test_v
                    min_cube = cube

    elapsed_time = time.time() - start

    print('found bounding box of volume %f in %f seconds' % (min_vol, elapsed_time))

    # Create the bounding box
    bpy.ops.mesh.primitive_cube_add()

    context.object.name = "AlignedBoundingBox"

    context.object.matrix_world = min_mx.inverted()
    # context.object.display_type = 'BOUNDS'
    for i, v in enumerate(min_cube):
        context.object.data.vertices[i].co = v

    # Normalize scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    # center origin
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')

    # capture rotation
    euler = context.object.rotation_euler.copy()

    # capture location
    location = context.object.location.copy()
    # capture scale
    scale = context.object.dimensions / 2

    # delete bounding box
    if not add_cube:
        bpy.ops.object.delete()

    if add_irradiance:
        bpy.ops.object.lightprobe_add(type='GRID', enter_editmode=False, location=location, rotation=euler)
        # Force the reference name
        context.object.name = irradiance_probe_name
        context.object.scale = scale
        context.object.rotation_euler = euler
        bpy.context.object.data.falloff = 0
        bpy.context.object.data.influence_distance = 0
        if drivers:
            mimic_radiance_param(context.object)
    if add_cube_map:
        bpy.ops.object.lightprobe_add(type='CUBEMAP', enter_editmode=False, location=location, rotation=euler)
        bpy.context.object.data.influence_type = 'BOX'
        bpy.context.object.data.falloff = 0
        bpy.context.object.data.influence_distance = 2
        # Force the reference name
        context.object.name = cube_map_probe_name
        context.object.scale = scale / 2
        context.object.rotation_euler = euler
        if drivers:
            mimic_cube_map_param(context.object)


class AdjustLightProbeOperator(bpy.types.Operator):
    """Blender dialog for adding light probes ajusted to objects or vertices"""
    bl_idname = "object.add_probes"
    bl_label = "Add aligned light probes"

    # generic transform props
    bounding_box: BoolProperty(
        name="bounding box",
        description='Add bounding box',
        default=False,
    )

    irradiance: BoolProperty(
        name="irradiance ",
        description='Add irradiance probe',
        default=False,
    )

    cube_map: BoolProperty(
        name="cube map",
        description='Add reflection cube map',
        default=False,
    )

    drivers: BoolProperty(
        name="Add mimic drivers",
        description='Add drivers to mimic the reference irradiance volume (named ' + IRRADIANCE_PROBE_BASE + ')',
        default=False,
    )
    nb_samples_rot_X: IntProperty(
        name="nb samples rot X",
        description='number of random directions to test calipers in',
        default=0)
    nb_samples_rot_Y: IntProperty(
        name="nb samples rot Y",
        description='angular step to rotate calipers 90 = 1 degree steps, 180 = 1/2 degree steps',
        default=0)
    nb_samples_rot_Z: IntProperty(
        name="nb samples rot Z",
        description='angular step to rotate calipers 90 = 1 degree steps, 180 = 1/2 degree steps',
        default=0)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(self, "bounding_box")
        layout = self.layout
        row = layout.row()
        row.prop(self, "irradiance")
        layout = self.layout
        row = layout.row()
        row.prop(self, "cube_map")

        row.prop(self, "drivers")

        row = layout.row()

        row.prop(self, "nb_samples_rot_X")

        row = layout.row()
        row.prop(self, "nb_samples_rot_Y")

        row = layout.row()
        row.prop(self, "nb_samples_rot_Z")

        pass

    def execute(self, context):
        main(context, self.nb_samples_rot_X, self.nb_samples_rot_Y, self.nb_samples_rot_Z, self.drivers,
             self.bounding_box, self.irradiance, self.cube_map)
        return {'FINISHED'}


classes = (
    AdjustLightProbeOperator,
)


#  add into a dynamic menu
def menu_func(self, context):
    self.layout.operator_context = 'INVOKE_DEFAULT'
    self.layout.operator(AdjustLightProbeOperator.bl_idname, text=AdjustLightProbeOperator.bl_label)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    bpy.types.VIEW3D_MT_edit_mesh.append(menu_func)
    bpy.types.VIEW3D_MT_object.append(menu_func)



def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    bpy.types.VIEW3D_MT_edit_mesh.remove(menu_func)
    bpy.types.VIEW3D_MT_object.remove(menu_func)


if __name__ == "__main__":
    register()

